#include <GL/glut.h>
#include <bits/stdc++.h>
using namespace std;

void drawPixel(int x, int y)
{
    glBegin(GL_POINTS);
    glVertex2i(x, y);
    glEnd();
}

// Bresenham
void bresenhamLine(int x1, int y1, int x2, int y2)
{
    int dx = abs(x2 - x1);
    int dy = abs(y2 - y1);

    int sx = (x1 < x2) ? 1 : -1;
    int sy = (y1 < y2) ? 1 : -1;

    int err = dx - dy;

    while (true)
    {
        drawPixel(x1, y1);

        if (x1 == x2 && y1 == y2)
            break;

        int e2 = 2 * err;

        if (e2 > -dy)
        {
            err -= dy;
            x1 += sx;
        }

        if (e2 < dx)
        {
            err += dx;
            y1 += sy;
        }
    }
}

void drawH(int x, int y)
{
    bresenhamLine(x, y, x, y + 100);
    bresenhamLine(x + 40, y, x + 40, y + 100);
    bresenhamLine(x, y + 50, x + 40, y + 50);
}

void drawE(int x, int y)
{
    bresenhamLine(x, y, x, y + 100);
    bresenhamLine(x, y + 100, x + 40, y + 100);
    bresenhamLine(x, y + 50, x + 30, y + 50);
    bresenhamLine(x, y, x + 40, y);
}

void drawL(int x, int y)
{
    bresenhamLine(x, y, x, y + 100);
    bresenhamLine(x, y, x + 40, y);
}

void drawO(int x, int y)
{
    // Rectangle O
    bresenhamLine(x, y, x + 50, y);
    bresenhamLine(x + 50, y, x + 50, y + 100);
    bresenhamLine(x + 50, y + 100, x, y + 100);
    bresenhamLine(x, y + 100, x, y);
}

void init()
{
    glClearColor(0, 0, 0, 0);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0, 500, 0, 500);
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(0, 1, 1);
    glPointSize(3);

    int startX = 50;
    int startY = 200;
    int gap = 70;

    drawH(startX, startY);
    drawE(startX + gap, startY);
    drawL(startX + 2 * gap, startY);
    drawL(startX + 3 * gap, startY);
    drawO(startX + 4 * gap, startY);

    glFlush();
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(500, 500);
    glutCreateWindow("HELLO using Bresenham");
    init();
    glutDisplayFunc(display);
    glutMainLoop();
    return 0;
}

