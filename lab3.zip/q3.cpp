#include <GL/glut.h>
#include <bits/stdc++.h>
using namespace std;

#define DOTTED 1
#define DOTTED_DASHED 2

void drawPixel(int x, int y)
{
    glBegin(GL_POINTS);
    glVertex2i(x, y);
    glEnd();
}

void bresenhamLineStyle(int x1, int y1, int x2, int y2, int style)
{
    int dx = abs(x2 - x1);
    int dy = abs(y2 - y1);

    int sx = (x1 < x2) ? 1 : -1;
    int sy = (y1 < y2) ? 1 : -1;

    int err = dx - dy;
    int count = 0;

    while (true)
    {
   
        if (style == DOTTED)
        {
            if (count % 4 == 0)     // draw one, skip three
                drawPixel(x1, y1);
        }
        else if (style == DOTTED_DASHED)
        {
            if (count % 10 == 0 || count % 10 == 1) // dot
                drawPixel(x1, y1);
            else if (count % 10 >= 4 && count % 10 <= 6) // dash
                drawPixel(x1, y1);
        }

        if (x1 == x2 && y1 == y2)
            break;

        int e2 = 2 * err;

        if (e2 > -dy)
        {
            err -= dy;
            x1 += sx;
        }

        if (e2 < dx)
        {
            err += dx;
            y1 += sy;
        }

        count++;
    }
}

void init()
{
    glClearColor(0, 0, 0, 0);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0, 500, 0, 500);
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(0, 1, 1);
    glPointSize(3);
    
    int x1, y1, x2, y2, style;
    cout << "Enter both coordinates : ";
    cin >> x1 >> y1 >> x2 >> y2;
    
    cout << "Enter style (1 or 2) : ";
    cin >> style;

    bresenhamLineStyle(x1,y1,x2,y2, style);

    glFlush();
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(500, 500);
    glutCreateWindow("Bresenham Line Styles");
    init();
    glutDisplayFunc(display);
    glutMainLoop();
    return 0;
}

