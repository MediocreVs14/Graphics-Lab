#include<GL/glut.h>
#include<bits/stdc++.h> 
#include<math.h>
#define pi 3.142857
using namespace std;

void init(){
	glClearColor(0.0, 0.0, 0.0, 0.0);
	glMatrixMode(GL_PROJECTION);
	gluOrtho2D(0.0, 500.0, 0.0, 500.0);
}

void display(){
	glClear(GL_COLOR_BUFFER_BIT);
	glColor3f(0.0, 1.0, 1.0);
	glPointSize(3.0);
	
	// DDA Algorithm
	
	float x1, x2, y1, y2;
	cout << "Enter both coordinates : ";
	cin >> x1 >> y1 >> x2 >> y2;
	
	// 0 < m <= 1
	//float x1 = 50, y1 = 50;
	//float x2 = 450, y2 = 350;
	
	// m > 1
	//float x1 = 200, y1 = 250;
	//float x2 = 300, y2 = 450;
	
	// -1 <= m < 0
	//float x1 = 150, y1 = 450;
	//float x2 = 300, y2 = 400;
	
	
	// m < -1
	//float x1 = 200, y1 = 450;
	//float x2 = 300, y2 = 250;
	
	float x = x1, y = y1;
	double m = (y2 - y1) / (x2 - x1);
	
	glVertex2i(x, y);
	
	if(m > 0 && m <= 1) {
		while(x <= x2 && y <= y2){
			glBegin(GL_POINTS);
			glVertex2i(x + 1, m + y);
			x++;
			y = m + y;
		}
		glEnd();
		glFlush();
	}
	else if(m < 0 && m >= -1){
		while(x <= x2 && y >= y2){
			glBegin(GL_POINTS);
			glVertex2i(x + 1, m + y);
			x++;
			y = m + y;
		}
		glEnd();
		glFlush();
	}
	else if(m > 1){
		while(x <= x2 && y <= y2){
			glBegin(GL_POINTS);
			glVertex2i(round(1.0/m + x), y + 1);
			y++;
			x = 1.0 / m + x;
		}
		glEnd();
		glFlush();
	}
	else if(m < -1){
		while(x <= x2 && y >= y2){
			glBegin(GL_POINTS);
			glVertex2i(round(1.0 / m + x), y - 1);
			y--;
			x = 1.0 / -m + x;
		}
		glEnd();
		glFlush();
	}
}

int main(int argc, char** argv){
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	glutInitWindowSize(500, 500);
	glutCreateWindow("Draw Point Example");
	init();
	glutDisplayFunc(display);
	glutMainLoop();
	return 0;
}
